from quantum_os.interfaces.gui import QuantumGUI

if __name__ == '__main__':
    gui = QuantumGUI()
    gui.run()
